#include <stdint.h>
#include "donothing.h"

void runExtCommand() {
  donothing();
}
