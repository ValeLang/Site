Vale Compiler, version 0.1.0
http://vale.dev/

To run a program:
  python3.8 ../valec.py (vale files here)
  ./a.out

To run benchmarks to see the differences between the various regions:
  cd benchmarks
  ./run_benchmark.sh

